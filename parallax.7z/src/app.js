$(document).ready(function () {

    var windowHeight = $(window).outerHeight(),
        backBird = $('#backBird'),
        logo = $('#logo'),
        bigBird = $('#bigBird'),
        header = $('header'),
        mainHeader = $('.main-header'),
        itemAreaHeight = $('.item-area').outerHeight(),
        itemAreaPos = $('.item-area').offset().top,
        itemBlock = $('.item-block'),
        itemPrevDesc = $('.item-preview-desc'),
        itemPrevPosition = $('.item-preview').offset().top;

    var scrollPos = $(this).scrollTop();

    var itemShow = function () {
        itemBlock.each(function (i) {
            setTimeout(function () {
                itemBlock.eq(i).addClass('show-item')
            }, (i + 1) * 100)
        })
    },
        previewAnimation = function () {
            itemPrevDesc.css({
                opacity: 1 - (itemPrevPosition - scrollPos) / 400
            })
        };

    if ((itemPrevPosition - mainHeader.outerHeight()) - scrollPos <= 400) {
        previewAnimation();
    }
    if (windowHeight > header.outerHeight() + $('#sectionTitle').outerHeight() + $('#sectionDesc').outerHeight() + 100) {
        itemShow();
    }

    $(document).on('scroll', function () {

        scrollPos = $(this).scrollTop();

        if (header.innerHeight() - mainHeader.innerHeight() < scrollPos) {
            if (!mainHeader.hasClass('show-menu')) {
                mainHeader.addClass('show-menu');
                if (!itemBlock.hasClass('show-item')) {
                    itemShow();
                }
            }
        } else if (mainHeader.hasClass('show-menu')) {
            mainHeader.removeClass('show-menu')
        }
        if (itemAreaPos - windowHeight/2 >= scrollPos &&
            windowHeight < header.outerHeight() + $('#sectionTitle').outerHeight() + $('#sectionDesc').outerHeight() + 100) {
            itemBlock.removeClass('show-item');
        }

        backBird.css({
            transform: 'translate(' + -scrollPos / 2 + 'px, ' + scrollPos + 'px)'
        });
        logo.css({ transform: 'translateX(' + -scrollPos + 'px)' })

        bigBird.css({
            transform: 'translate(0px, ' + -scrollPos * 0.8 + 'px)'
        });

        //preview animation
        if ((itemPrevPosition - mainHeader.outerHeight()) - scrollPos <= 400 && itemPrevPosition - scrollPos >= mainHeader.outerHeight()) {
            previewAnimation();
        }

        //blog animation
        if($('.blog-area').offset().top - windowHeight < scrollPos) {
            var offset = Math.min(0, scrollPos - $('.blog-area').offset().top + windowHeight/3);
            $('.post-1').css({
                transform: 'translate('+offset+'px, '+-offset/3.3+'px)'
            })
            $('.post-3').css({
                transform: 'translate('+Math.abs(offset)+'px, '+-offset/3.3+'px)'
            })                        
        }
    })
})