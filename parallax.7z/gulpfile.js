const gulp = require('gulp');
const sass = require('gulp-sass');
const browserSync = require('browser-sync').create();

gulp.task('sass', function() {
    return gulp.src('src/app.scss')
        .pipe(sass())
        .pipe(gulp.dest("src/css"))
        .pipe(browserSync.stream());
});

gulp.task('watch', ['sass'], function() {
    browserSync.init ({
        server: './src'
    })
    gulp.watch('src/*.scss', ['sass'])
})